package com.zalx.lunex

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.regex.Pattern

private val Midnight = Color(0xFF07090E)
private val SurfaceDark = Color(0xFF151D2B)
private val Blue = Color(0xFF38BDF8)
private val Cyan = Color(0xFF06B6D4)
private val Violet = Color(0xFF8B5CF6)
private val Muted = Color(0xFF94A3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Midnight, surface = SurfaceDark)) { LunexApp() } }
    }
}

private enum class SpeechMode { LOCAL_DEVICE, ELEVEN_LABS, GOOGLE_CLOUD }

private class NaturalSpeechProcessor {
    private val currency = Pattern.compile("(?i)(\\$|€|£|₹)\\s?(\\d+(?:\\.\\d{1,2})?)")
    private val percent = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s?%")

    fun normalize(input: String): String {
        val matcher = currency.matcher(input)
        val buffer = StringBuffer()
        while (matcher.find()) {
            val unit = when (matcher.group(1)) { "$" -> " dollars"; "€" -> " euros"; "£" -> " pounds"; "₹" -> " rupees"; else -> "" }
            matcher.appendReplacement(buffer, MatcherQuote.quoteReplacement((matcher.group(2) ?: "") + unit))
        }
        matcher.appendTail(buffer)
        return percent.matcher(buffer.toString()).replaceAll("$1 percent")
            .replace(Regex("https?://\\S+"), "web link")
    }
}

private object MatcherQuote {
    fun quoteReplacement(value: String): String = value.replace("\\", "\\\\").replace("$", "\\$")
}

private class CloudTtsEngine(private val context: Context) {
    private var player: MediaPlayer? = null

    suspend fun eleven(text: String, apiKey: String, voiceId: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Enter your ElevenLabs API key in Settings." }
            val conn = (URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                setRequestProperty("xi-api-key", apiKey); setRequestProperty("Content-Type", "application/json")
            }
            try {
                conn.outputStream.use { it.write(JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2").toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (code !in 200..299) error("ElevenLabs request failed (HTTP $code). Check API key, voice ID, and quota.")
                File(context.cacheDir, "lunex_eleven.mp3").also { file -> conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } } }
            } finally { conn.disconnect() }
        }
    }

    suspend fun google(text: String, apiKey: String, voiceName: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Enter your Google Cloud API key in Settings." }
            val lang = voiceName.substringBeforeLast('-', "en-US")
            val conn = (URL("https://texttospeech.googleapis.com/v1/text:synthesize?key=$apiKey").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            try {
                val body = JSONObject().put("input", JSONObject().put("text", text))
                    .put("voice", JSONObject().put("languageCode", lang).put("name", voiceName))
                    .put("audioConfig", JSONObject().put("audioEncoding", "MP3"))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (code !in 200..299) error("Google TTS request failed (HTTP $code). Check API key, billing, and quota.")
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val bytes = Base64.decode(JSONObject(response).getString("audioContent"), Base64.DEFAULT)
                File(context.cacheDir, "lunex_google.mp3").also { it.writeBytes(bytes) }
            } finally { conn.disconnect() }
        }
    }

    fun play(file: File, onDone: () -> Unit, onError: (String) -> Unit) {
        stop()
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).build())
                setDataSource(file.absolutePath)
                setOnCompletionListener { stop(); onDone() }
                setOnErrorListener { _, what, extra -> stop(); onError("Audio playback failed ($what/$extra)."); true }
                prepare(); start()
            }
        } catch (e: Exception) { stop(); onError(e.message ?: "Could not play audio.") }
    }

    fun stop() { try { player?.stop() } catch (_: Exception) {}; player?.release(); player = null }
}

private class LocalTts(context: Context, private val onReady: (Boolean) -> Unit) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    @Volatile var ready = false
        private set
    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS; onReady(ready) }
    fun speak(text: String, rate: Float, pitch: Float): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        engine.language = Locale.getDefault(); engine.setSpeechRate(rate); engine.setPitch(pitch)
        return engine.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), "LUNEX_${System.currentTimeMillis()}") == TextToSpeech.SUCCESS
    }
    fun stop() { tts?.stop() }
    fun release() { tts?.stop(); tts?.shutdown(); tts = null; ready = false }
}

@Composable
private fun LunexApp() {
    var showStartup by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(2400); showStartup = false }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val processor = remember { NaturalSpeechProcessor() }
    var input by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(SpeechMode.LOCAL_DEVICE) }
    var elevenKey by remember { mutableStateOf("") }
    var googleKey by remember { mutableStateOf("") }
    var elevenVoice by remember { mutableStateOf("21m00Tcm4TlvDq8ikWAM") }
    var googleVoice by remember { mutableStateOf("en-US-Neural2-F") }
    var rate by remember { mutableStateOf(1f) }
    var pitch by remember { mutableStateOf(1f) }
    var status by remember { mutableStateOf("Ready when you are.") }
    var speaking by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }
    val localTts = remember { LocalTts(context) { ttsReady = it } }
    val cloud = remember { CloudTtsEngine(context) }
    DisposableEffect(Unit) { onDispose { localTts.release(); cloud.stop() } }

    Surface(Modifier.fillMaxSize(), color = Midnight) {
        Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(26.dp))
            Text("LUNEX", color = Blue, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("Advanced AI TTS & Natural Accessibility", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            VoiceOrb(speaking)
            Text(status, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Enter text to speak") }, modifier = Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeButton("Local TTS", mode == SpeechMode.LOCAL_DEVICE, Modifier.weight(1f)) { mode = SpeechMode.LOCAL_DEVICE }
                ModeButton("ElevenLabs", mode == SpeechMode.ELEVEN_LABS, Modifier.weight(1f)) { mode = SpeechMode.ELEVEN_LABS }
                ModeButton("Google", mode == SpeechMode.GOOGLE_CLOUD, Modifier.weight(1f)) { mode = SpeechMode.GOOGLE_CLOUD }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    if (input.isBlank()) { status = "Enter some text first."; return@Button }
                    val text = processor.normalize(input.trim())
                    speaking = true; status = "Preparing speech…"
                    when (mode) {
                        SpeechMode.LOCAL_DEVICE -> { if (localTts.speak(text, rate, pitch)) status = if (ttsReady) "Speaking with your device voice." else "Starting device TTS…" else { speaking = false; status = "Device TTS is not ready. Try again or choose an installed TTS engine in Android settings." } }
                        SpeechMode.ELEVEN_LABS -> scope.launch { val result = cloud.eleven(text, elevenKey, elevenVoice); result.fold({ file -> withContext(Dispatchers.Main) { status = "Speaking with ElevenLabs."; cloud.play(file, { speaking = false; status = "Finished." }, { err -> speaking = false; status = err }) } }, { err -> speaking = false; status = err.message ?: "Cloud TTS failed." }) }
                        SpeechMode.GOOGLE_CLOUD -> scope.launch { val result = cloud.google(text, googleKey, googleVoice); result.fold({ file -> withContext(Dispatchers.Main) { status = "Speaking with Google Cloud."; cloud.play(file, { speaking = false; status = "Finished." }, { err -> speaking = false; status = err }) } }, { err -> speaking = false; status = err.message ?: "Cloud TTS failed." }) }
                    }
                }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Midnight)) { Text("▶ Speak") }
                Button(onClick = { localTts.stop(); cloud.stop(); speaking = false; status = "Speech stopped." }, modifier = Modifier.weight(1f)) { Text("■ Stop") }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { settingsOpen = !settingsOpen }) { Text(if (settingsOpen) "Hide Settings" else "⚙ Voice & API Settings") }
                TextButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Enable Screen Reader") }
            }
            if (settingsOpen) {
                OutlinedTextField(value = elevenKey, onValueChange = { elevenKey = it }, label = { Text("ElevenLabs API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = elevenVoice, onValueChange = { elevenVoice = it }, label = { Text("ElevenLabs voice ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = googleKey, onValueChange = { googleKey = it }, label = { Text("Google Cloud API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = googleVoice, onValueChange = { googleVoice = it }, label = { Text("Google voice name (e.g. en-US-Neural2-F)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Text("Speech rate: ${"%.1f".format(rate)}×", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(0.75f, 1f, 1.25f, 1.5f).forEach { value -> TextButton(onClick = { rate = value }) { Text("${value}×") } } }
                Text("Pitch: ${"%.1f".format(pitch)}×", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(0.8f, 1f, 1.2f).forEach { value -> TextButton(onClick = { pitch = value }) { Text("${value}×") } } }
                Text("Cloud keys are kept only in this screen's memory in this demo; they are not persisted. Do not ship API secrets in a public app. Use a secured backend for production.", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(24.dp))
            Text("ZALX creations", color = Muted.copy(alpha = .7f), fontSize = 11.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(18.dp))
        }
        if (showStartup) {
            val splashTransition = rememberInfiniteTransition(label = "lunex-logo-splash")
            val splashScale by splashTransition.animateFloat(0.94f, 1.04f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "logo-pulse")
            Box(Modifier.fillMaxSize().background(Midnight), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painter = painterResource(id = R.drawable.lunex_logo), contentDescription = "Original LUNEX app logo", modifier = Modifier.fillMaxWidth(0.88f).scale(splashScale))
                    Spacer(Modifier.height(18.dp))
                    Text("Advanced AI TTS & Natural Accessibility", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(20.dp))
                    Text("ZALX creations", color = Muted.copy(alpha = .8f), fontSize = 11.sp, letterSpacing = 1.3.sp)
                }
            }
        }
        }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier, colors = ButtonDefaults.buttonColors(containerColor = if (selected) Blue else SurfaceDark, contentColor = if (selected) Midnight else Color.White), shape = RoundedCornerShape(12.dp)) { Text(label, fontSize = 11.sp) }
}

@Composable
private fun VoiceOrb(speaking: Boolean) {
    val transition = rememberInfiniteTransition(label = "lunex-orb")
    val scale by transition.animateFloat(if (speaking) .9f else .98f, if (speaking) 1.12f else 1.02f, infiniteRepeatable(tween(if (speaking) 700 else 2100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale")
    Box(Modifier.size(190.dp).semantics { contentDescription = if (speaking) "LUNEX speaking" else "LUNEX idle" }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(170.dp * scale)) {
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = .8f), Violet.copy(alpha = .35f), Blue.copy(alpha = 0f))))
            drawCircle(Brush.sweepGradient(listOf(Blue, Violet, Cyan, Blue)), style = Stroke(width = 3.dp.toPx()))
        }
        Box(Modifier.size(92.dp).clip(RoundedCornerShape(50)).background(Brush.linearGradient(listOf(Color(0xFF0F2E50), Color(0xFF123B62), Color(0xFF17152F)))))
    }
}

class LunexAccessibilityService : AccessibilityService() {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var lastUtterance = ""
    private var lastAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        tts = TextToSpeech(applicationContext) { result -> ready = result == TextToSpeech.SUCCESS }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !ready) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_FOCUSED,
            AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED,
            AccessibilityEvent.TYPE_VIEW_SELECTED,
            AccessibilityEvent.TYPE_VIEW_CLICKED -> event.source?.let { node ->
                try { readNode(node) } finally { node.recycle() }
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val name = event.className?.toString()?.substringAfterLast('.') ?: return
                speak("Screen changed: $name")
            }
        }
    }

    private fun readNode(node: AccessibilityNodeInfo) {
        if (node.isPassword) { speak("Password field"); return }
        val label = node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
            ?: node.text?.toString()?.takeIf { it.isNotBlank() }
            ?: return
        val details = buildList {
            add(label)
            if (node.isCheckable) add(if (node.isChecked) "Checked" else "Not checked")
            if (node.isClickable) add("Button")
            if (node.isSelected) add("Selected")
        }.joinToString(", ")
        speak(details)
    }

    private fun speak(text: String) {
        val now = System.currentTimeMillis()
        if (text == lastUtterance && now - lastAt < 900) return
        lastUtterance = text; lastAt = now
        tts?.speak(NaturalSpeechProcessor().normalize(text), TextToSpeech.QUEUE_FLUSH, Bundle(), "LUNEX_A11Y_${now}")
    }

    override fun onInterrupt() { tts?.stop() }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); tts = null; super.onDestroy() }
}
